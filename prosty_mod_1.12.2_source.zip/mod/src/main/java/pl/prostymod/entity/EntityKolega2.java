package pl.prostymod.entity;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityKolega2 extends EntityKolega {
    private static final ResourceLocation TEX = tex("kolega2");

    public EntityKolega2(World world) {
        super(world);
    }

    @Override
    public ResourceLocation getTexture() {
        return TEX;
    }
}

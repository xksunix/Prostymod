package pl.prostymod.entity;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityKolega1 extends EntityKolega {
    private static final ResourceLocation TEX = tex("kolega1");

    public EntityKolega1(World world) {
        super(world);
    }

    @Override
    public ResourceLocation getTexture() {
        return TEX;
    }
}

package pl.prostymod.entity;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityKolega3 extends EntityKolega {
    private static final ResourceLocation TEX = tex("kolega3");

    public EntityKolega3(World world) {
        super(world);
    }

    @Override
    public ResourceLocation getTexture() {
        return TEX;
    }
}

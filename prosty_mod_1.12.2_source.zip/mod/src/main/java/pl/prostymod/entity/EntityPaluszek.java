package pl.prostymod.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;
import net.minecraft.entity.EntityCreature;
import pl.prostymod.ProstyMod;

import javax.annotation.Nullable;

/** Paluszek rybny - spokojny mob z glosem z filmiku. Prawy klik = gada. */
public class EntityPaluszek extends EntityCreature {

    public EntityPaluszek(World world) {
        super(world);
        setSize(0.5F, 1.5F);
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIPanic(this, 1.4D));
        tasks.addTask(2, new EntityAIWanderAvoidWater(this, 1.0D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(4, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(10.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (!world.isRemote) {
            world.playSound(null, posX, posY, posZ, ProstyMod.PALUSZEK_SAY, SoundCategory.NEUTRAL, 1.0F, 1.0F);
        }
        return true;
    }

    @Override
    public int getTalkInterval() {
        return 400;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return ProstyMod.PALUSZEK_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ProstyMod.PALUSZEK_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ProstyMod.PALUSZEK_DEATH;
    }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        dropItem(Items.COOKED_FISH, 1 + rand.nextInt(2));
    }
}

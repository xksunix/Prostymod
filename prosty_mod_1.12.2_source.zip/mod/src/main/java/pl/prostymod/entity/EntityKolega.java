package pl.prostymod.entity;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import pl.prostymod.ProstyMod;

/** Spokojny, humanoidalny mob z twarza na teksturze. */
public abstract class EntityKolega extends EntityCreature {

    public EntityKolega(World world) {
        super(world);
        setSize(0.6F, 1.8F);
    }

    public abstract ResourceLocation getTexture();

    protected static ResourceLocation tex(String name) {
        return new ResourceLocation(ProstyMod.MODID, "textures/entity/" + name + ".png");
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIPanic(this, 1.3D));
        tasks.addTask(2, new EntityAIWanderAvoidWater(this, 0.9D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(4, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
    }
}

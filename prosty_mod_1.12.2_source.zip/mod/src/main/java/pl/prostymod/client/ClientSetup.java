package pl.prostymod.client;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import pl.prostymod.ProstyMod;
import pl.prostymod.entity.*;

@SideOnly(Side.CLIENT)
public class ClientSetup {

    public static void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityPaluszek.class, RenderPaluszek::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityKolega1.class, RenderKolega::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityKolega2.class, RenderKolega::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityKolega3.class, RenderKolega::new);
    }

    public static class RenderPaluszek extends RenderLiving<EntityPaluszek> {
        private static final ResourceLocation TEX = new ResourceLocation(ProstyMod.MODID, "textures/entity/paluszek.png");

        public RenderPaluszek(RenderManager rm) {
            super(rm, new ModelPaluszek(), 0.3F);
        }

        @Override
        protected ResourceLocation getEntityTexture(EntityPaluszek entity) {
            return TEX;
        }
    }

    public static class RenderKolega extends RenderLiving<EntityKolega> {
        public RenderKolega(RenderManager rm) {
            super(rm, new ModelBiped(), 0.5F);
        }

        @Override
        protected ResourceLocation getEntityTexture(EntityKolega entity) {
            return entity.getTexture();
        }
    }
}

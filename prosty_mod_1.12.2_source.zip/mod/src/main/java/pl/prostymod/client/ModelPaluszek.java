package pl.prostymod.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ModelPaluszek extends ModelBase {
    private final ModelRenderer body, legR, legL, armR, armL;

    public ModelPaluszek() {
        textureWidth = 64;
        textureHeight = 64;

        body = new ModelRenderer(this, 0, 0);
        body.addBox(-3F, -14F, -3F, 6, 14, 6);
        body.setRotationPoint(0F, 20F, 0F);

        legR = new ModelRenderer(this, 0, 20);
        legR.addBox(-1F, 0F, -1F, 2, 4, 2);
        legR.setRotationPoint(-1.5F, 20F, 0F);

        legL = new ModelRenderer(this, 8, 20);
        legL.addBox(-1F, 0F, -1F, 2, 4, 2);
        legL.setRotationPoint(1.5F, 20F, 0F);

        armR = new ModelRenderer(this, 0, 26);
        armR.addBox(-1F, 0F, -1F, 2, 7, 2);
        armR.setRotationPoint(-4F, 8F, 0F);

        armL = new ModelRenderer(this, 8, 26);
        armL.addBox(-1F, 0F, -1F, 2, 7, 2);
        armL.setRotationPoint(4F, 8F, 0F);
    }

    @Override
    public void render(Entity e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, e);
        body.render(scale);
        legR.render(scale);
        legL.render(scale);
        armR.render(scale);
        armL.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity e) {
        legR.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        legL.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
        armR.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.2F * limbSwingAmount;
        armL.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        body.rotateAngleY = yaw * 0.0174532925F * 0.3F;
    }
}

package pl.prostymod;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import pl.prostymod.entity.*;

@Mod(modid = ProstyMod.MODID, name = "Prosty Mod", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
@Mod.EventBusSubscriber
public class ProstyMod {
    public static final String MODID = "prostymod";

    @Mod.Instance(MODID)
    public static ProstyMod instance;

    public static SoundEvent PALUSZEK_AMBIENT, PALUSZEK_HURT, PALUSZEK_DEATH, PALUSZEK_SAY;

    private static SoundEvent sound(String name) {
        ResourceLocation rl = new ResourceLocation(MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    @SubscribeEvent
    public static void registerSounds(RegistryEvent.Register<SoundEvent> e) {
        PALUSZEK_AMBIENT = sound("paluszek.ambient");
        PALUSZEK_HURT = sound("paluszek.hurt");
        PALUSZEK_DEATH = sound("paluszek.death");
        PALUSZEK_SAY = sound("paluszek.say");
        e.getRegistry().registerAll(PALUSZEK_AMBIENT, PALUSZEK_HURT, PALUSZEK_DEATH, PALUSZEK_SAY);
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        int id = 0;
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "paluszek"), EntityPaluszek.class, "paluszek", id++, this, 64, 1, true, 0xE8963C, 0x1E1E1E);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "kolega1"), EntityKolega1.class, "kolega1", id++, this, 64, 1, true, 0x12161F, 0x5C4030);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "kolega2"), EntityKolega2.class, "kolega2", id++, this, 64, 1, true, 0x1C346E, 0x966E50);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "kolega3"), EntityKolega3.class, "kolega3", id++, this, 64, 1, true, 0x8C8C91, 0x463C37);

        if (event.getSide() == Side.CLIENT) {
            pl.prostymod.client.ClientSetup.registerRenderers();
        }
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Biome[] biomes = ForgeRegistries.BIOMES.getValues().toArray(new Biome[0]);
        EntityRegistry.addSpawn(EntityPaluszek.class, 12, 1, 3, EnumCreatureType.CREATURE, biomes);
        EntityRegistry.addSpawn(EntityKolega1.class, 6, 1, 2, EnumCreatureType.CREATURE, biomes);
        EntityRegistry.addSpawn(EntityKolega2.class, 6, 1, 2, EnumCreatureType.CREATURE, biomes);
        EntityRegistry.addSpawn(EntityKolega3.class, 6, 1, 2, EnumCreatureType.CREATURE, biomes);
    }
}

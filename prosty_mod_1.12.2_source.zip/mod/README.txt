PROSTY MOD 1.12.2 (Forge 1.12.2-14.23.5.2860) - Java 8!

BUDOWANIE:
1. Pobierz Forge MDK 1.12.2 (14.23.5.2860) z files.minecraftforge.net, rozpakuj.
2. Podmien w MDK folder "src" na ten z tego projektu i plik build.gradle.
3. W folderze: gradlew setupDecompWorkspace, potem gradlew build
4. Gotowy mod: build/libs/prostymod-1.0.jar -> do folderu mods.

W GRZE:
- Spawn jajka (kreatywny): Paluszek, Kolega 1, 2, 3 + naturalnie spawnują się wszędzie
- Paluszek: prawy klik = gada glosem z filmiku, losowo sam gada, krzyczy jak oberwie
- Kolega 1/2/3: twarze na teksturach (assets/prostymod/textures/entity/kolega1..3.png)

BUDOWANIE PRZEZ GITHUB (bez instalowania niczego):
1. Zaloguj sie na github.com, utworz nowe repozytorium (New repository).
2. Wrzuc do niego ZAWARTOSC folderu "mod" (src, build.gradle, .github) - Add file > Upload files.
   UWAGA: folder .github musi sie wgrac (jest ukryty - jesli nie, utworz plik recznie: .github/workflows/build.yml).
3. Zakladka Actions > "Build mod" > poczekaj az sie zazieleni (kilka minut).
4. Wejdz w ten przebieg > na dole Artifacts > prostymod-jar - to zip z gotowym .jar.
